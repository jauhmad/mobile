package com.pratamawijaya.androidrecyclerview.domain

data class Hero(
        val name: String,
        val image: String
)