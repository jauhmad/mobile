# SimpleRecyclerviewKotlin

Example how to use Recyclerview in Android
